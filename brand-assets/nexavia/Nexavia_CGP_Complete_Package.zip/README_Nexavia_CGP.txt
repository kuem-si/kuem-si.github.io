NEXAVIA CGP - COMPLETE VECTOR PACKAGE

Main files
- Nexavia_CGP_Dark.pdf: full Dark visual identity and interface guide
- Nexavia_CGP_Light.pdf: full Light visual identity and interface guide
- Nexavia_CGP_Dark_Master.ai: PDF-compatible vector master for Adobe Illustrator
- Nexavia_CGP_Light_Master.ai: PDF-compatible vector master for Adobe Illustrator
- Nexavia_CGP_Dark_Master.svg: open editable vector master with named groups
- Nexavia_CGP_Light_Master.svg: open editable vector master with named groups

Logo assets
- Nexavia_Logo_Dark.svg
- Nexavia_Logo_Light.svg
- Nexavia_by_KUEM_Dark.svg
- Nexavia_by_KUEM_Light.svg
- Nexavia_App_Icon.svg
- KUEM_Official_Wordmark.svg

Development handoff
- Nexavia_Design_Tokens.json
- Nexavia_Design_Tokens.css

Adobe Illustrator
The .ai files are PDF-compatible vector masters. Open them directly in Adobe Illustrator. The SVG files preserve the clearest named group structure and are also suitable for Figma and browser-based development. Before final production, install Space Grotesk and Source Sans 3 or convert text to outlines.

Brand rule
Nexavia is the primary product identity. The by KUEM endorsement is secondary. Platform Blue and Data Cyan belong to Nexavia; Signal Copper is the visual connection to KUEM and must be used sparingly.
