KAI CGP - COMPLETE VECTOR PACKAGE

Main files
- KAI_CGP_Dark.pdf: full Dark identity and interface guide
- KAI_CGP_Light.pdf: full Light identity and interface guide
- KAI_CGP_Dark_Master.ai: PDF-compatible vector master for Adobe Illustrator
- KAI_CGP_Light_Master.ai: PDF-compatible vector master for Adobe Illustrator
- KAI_CGP_Dark_Master.svg: open editable vector master with named groups
- KAI_CGP_Light_Master.svg: open editable vector master with named groups

Logo assets
- KAI_Logo_Dark.svg
- KAI_Logo_Light.svg
- KAI_by_KUEM_Dark.svg
- KAI_by_KUEM_Light.svg
- KAI_App_Icon.svg
- KUEM_Official_Wordmark.svg

Development handoff
- KAI_Design_Tokens.json
- KAI_Design_Tokens.css

Adobe Illustrator
The .ai files are PDF-compatible vector masters. Open them directly in Adobe Illustrator. SVG files preserve the clearest named group structure and are also suitable for Figma and browser-based development. Install Space Grotesk and Source Sans 3 or convert text to outlines before final production.

Brand rule
KAI is the primary assistant identity. by KUEM is the ownership endorsement. Works with Nexavia is an integration badge and never part of the KAI logo. Insight Indigo is primary; Evidence Cyan denotes direct data; Signal Copper denotes focus or an action point.
