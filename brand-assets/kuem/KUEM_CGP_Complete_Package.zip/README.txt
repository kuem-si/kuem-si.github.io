KUEM CGP - VECTOR PACKAGE

Files
- KUEM_CGP_Core.pdf: full Core/Dark visual identity manual
- KUEM_CGP_Light.pdf: full Light visual identity manual
- KUEM_CGP_Core_Master.ai: PDF-compatible vector master for Adobe Illustrator
- KUEM_CGP_Light_Master.ai: PDF-compatible vector master for Adobe Illustrator
- KUEM_CGP_Core_Master.svg: editable open vector master
- KUEM_CGP_Light_Master.svg: editable open vector master
- KUEM_Official_Wordmark.svg: official KUEM vector wordmark extracted from kuem.si

Important
The .ai files are PDF-compatible fully vector files. Open them directly in Adobe Illustrator. Named SVG groups provide the clearest layer structure for ongoing editing. Before production, outline type or install Space Grotesk and Source Sans 3.

Fonts
Space Grotesk and Source Sans 3 are open-source fonts distributed under the SIL Open Font License.
